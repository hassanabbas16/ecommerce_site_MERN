# MERN Stack Eccommerce WebSite
Demo https://store.fayzullodev.uz

Description: MERN stands for MongoDB, Express.js, React.js and Node.js - and combined, these four technologies allow you to build amazing web applications

Description: This project includes the login and signup part for every user, only those who log in the website can create posts with rich text. Posts are divided in two parts: 1. Post subtitle, 2. Post details. This project will have technology - Nodejs Express framework Mongodb Mongoose ODM Express sessions Mongoose data validation Express Middleware & Request interception User authentication and authorization Dynamic views with templating engines Model View Controller design pattern Password security and hashing Mongoose model hooks
